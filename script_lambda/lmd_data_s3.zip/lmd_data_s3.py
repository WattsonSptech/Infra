import json, os, time, uuid, boto3
from decimal import Decimal
from datetime import datetime

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # evento vindo do IoT Core Rule -> JSON em 'event'
    # Ex.: {"deviceId":"sensor-001","temp":24.2,"hum":60}
    try:
        msg = event if isinstance(event, dict) else json.loads(event)
        device_id = str(msg.get("deviceId", "unknown"))
        ts = int(time.time()*1000)

        item = json.dumps({
            "deviceId": device_id,
            "ts": ts,
            "id": uuid.uuid4().hex,
            "temp": str(msg.get("temp", 0)),
            "hum": msg.get("hum", 0),
            "raw": json.dumps(msg)
        })
        
        s3_client.put_object(
            Bucket="bkt-wattson-raw-637952174709",
            Key=f"telemetry_{device_id}_{datetime.now().isoformat()}.json",
            Body=item,
            ContentType=event.get('content_type', 'text/plain')
        )

        return {"status": "ok", "saved": {"deviceId": device_id, "ts": ts}}
    except Exception as e:
        return {"status": "error", "detail": str(e)}